package com.storytoons.app

data class Character(val id: String, val name: String, val desc: String)

data class Scene(
    val id: Int,
    val text: String,
    val camera: String,
    val chain: Boolean = true,
    val clipPath: String? = null,
    val status: String = "Not generated",
    val error: String? = null,
    val busy: Boolean = false
)

object Styles {
    val all = linkedMapOf(
        "Horror cartoon" to "2D flat vector Indian horror cartoon, dark night atmosphere, muted green and teal palette, soft rim lighting, simple clean shapes",
        "Comic realistic" to "Semi-realistic graphic-novel cartoon, thick ink outlines, cel shading, expressive faces, moody cinematic lighting, detailed backgrounds"
    )
}

object Cameras {
    val all = listOf(
        "Wide establishing shot, slow push-in",
        "Medium shot, subtle handheld movement",
        "Close-up on the face, shallow depth of field",
        "Slow pan from left to right",
        "Tracking shot following the character from behind",
        "Over-the-shoulder shot",
        "Side-profile tracking shot",
        "Low angle, slow tilt up"
    )
}

const val CLIP_SECONDS = 8
