package com.storytoons.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("storytoons", Context.MODE_PRIVATE)

    var apiKey: String
        get() = p.getString("key", "") ?: ""
        set(v) { p.edit().putString("key", v).apply() }

    var baseUrl: String
        get() = p.getString("base", "https://api.atlascloud.ai/api/v1/model") ?: ""
        set(v) { p.edit().putString("base", v).apply() }

    var modelWithRefs: String
        get() = p.getString("mref", "bytedance/seedance-2.5/reference-to-video") ?: ""
        set(v) { p.edit().putString("mref", v).apply() }

    var modelTextOnly: String
        get() = p.getString("mtxt", "bytedance/seedance-2.5/text-to-video") ?: ""
        set(v) { p.edit().putString("mtxt", v).apply() }

    var style: String
        get() = p.getString("style", "Horror cartoon") ?: "Horror cartoon"
        set(v) { p.edit().putString("style", v).apply() }

    var story: String
        get() = p.getString("story", "") ?: ""
        set(v) { p.edit().putString("story", v).apply() }

    fun loadCharacters(): List<Character> {
        val arr = JSONArray(p.getString("chars", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Character(
                o.getString("id"), o.getString("name"), o.getString("desc"),
                o.optString("sheet").ifBlank { null }
            )
        }
    }

    fun saveCharacters(list: List<Character>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name)
                .put("desc", it.desc).put("sheet", it.sheetPath ?: ""))
        }
        p.edit().putString("chars", arr.toString()).apply()
    }
}
