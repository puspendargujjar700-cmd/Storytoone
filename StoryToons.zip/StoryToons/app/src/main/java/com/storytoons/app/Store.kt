package com.storytoons.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("storytoons2", Context.MODE_PRIVATE)
    private fun s(k: String, d: String) = p.getString(k, d) ?: d
    private fun put(k: String, v: String) { p.edit().putString(k, v).apply() }

    init {
        if (p.getInt("ver", 0) < 4) {
            val e = p.edit()
            if (s("vmodel", "").startsWith("veo")) e.putString("vmodel", "gemini-omni-1.1-flash")
            if (s("tmodel", "").startsWith("gemini-2")) e.putString("tmodel", "gemini-3.8-flash")
            e.putInt("ver", 4).apply()
        }
    }

    var apiKey: String get() = s("key", ""); set(v) = put("key", v)
    var baseUrl: String
        get() = s("base", "https://generativelanguage.googleapis.com/v1beta"); set(v) = put("base", v)
    var videoModel: String get() = s("vmodel", "gemini-omni-1.1-flash"); set(v) = put("vmodel", v)
    var textModel: String get() = s("tmodel", "gemini-3.8-flash"); set(v) = put("tmodel", v)
    var imageModel: String get() = s("imodel", "gemini-3.1-flash-image"); set(v) = put("imodel", v)
    var resolution: String get() = s("res", "720p"); set(v) = put("res", v)
    var style: String get() = s("style", "Horror cartoon"); set(v) = put("style", v)
    var story: String get() = s("story", ""); set(v) = put("story", v)
    var world: String get() = s("world", ""); set(v) = put("world", v)
    var minutes: Int get() = p.getInt("minutes", 1); set(v) { p.edit().putInt("minutes", v).apply() }

    fun loadCharacters(): List<Character> {
        val a = JSONArray(s("chars", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Character(o.getString("id"), o.getString("name"), o.optString("desc"),
                o.optString("voice"), o.optString("sheet").ifBlank { null })
        }
    }

    fun saveCharacters(l: List<Character>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("desc", it.desc)
                .put("voice", it.voice).put("sheet", it.sheetPath ?: ""))
        }
        put("chars", a.toString())
    }

    fun loadPlaces(): List<Place> {
        val a = JSONArray(s("places", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Place(o.getString("id"), o.getString("name"), o.optString("desc"),
                o.optString("img").ifBlank { null })
        }
    }

    fun savePlaces(l: List<Place>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("desc", it.desc)
                .put("img", it.imagePath ?: ""))
        }
        put("places", a.toString())
    }

    fun loadScenes(): List<Scene> {
        val a = JSONArray(s("scenes", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val clip = o.optString("clip").ifBlank { null }
            val cj = o.optJSONArray("chars")
            val chars = if (cj == null) emptyList() else (0 until cj.length()).map { i -> cj.getString(i) }
            Scene(o.getInt("id"), o.getString("text"), o.getString("camera"), o.optString("loc"), chars,
                clip, if (clip != null) "Ready" else "Not generated")
        }
    }

    fun saveScenes(l: List<Scene>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("text", it.text).put("camera", it.camera)
                .put("loc", it.location).put("chars", JSONArray(it.chars)).put("clip", it.clipPath ?: ""))
        }
        put("scenes", a.toString())
    }
}
