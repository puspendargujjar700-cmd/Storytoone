package com.storytoons.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("storytoons2", Context.MODE_PRIVATE)
    private fun s(k: String, d: String) = p.getString(k, d) ?: d
    private fun put(k: String, v: String) { p.edit().putString(k, v).apply() }

    var apiKey: String get() = s("key", ""); set(v) = put("key", v)
    var baseUrl: String
        get() = s("base", "https://generativelanguage.googleapis.com/v1beta"); set(v) = put("base", v)
    var videoModel: String
        get() = s("vmodel", "veo-3.1-lite-generate-preview"); set(v) = put("vmodel", v)
    var textModel: String get() = s("tmodel", "gemini-2.5-flash"); set(v) = put("tmodel", v)
    var pricePerSec: Float get() = p.getFloat("price", 0.05f); set(v) { p.edit().putFloat("price", v).apply() }
    var limitUsd: Float get() = p.getFloat("limit", 10f); set(v) { p.edit().putFloat("limit", v).apply() }
    var spentUsd: Float get() = p.getFloat("spent", 0f); set(v) { p.edit().putFloat("spent", v).apply() }
    var style: String get() = s("style", "Horror cartoon"); set(v) = put("style", v)
    var story: String get() = s("story", ""); set(v) = put("story", v)
    var world: String get() = s("world", ""); set(v) = put("world", v)
    var minutes: Int get() = p.getInt("minutes", 1); set(v) { p.edit().putInt("minutes", v).apply() }

    fun loadCharacters(): List<Character> {
        val a = JSONArray(s("chars", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Character(o.getString("id"), o.getString("name"), o.getString("desc"))
        }
    }

    fun saveCharacters(l: List<Character>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("desc", it.desc)) }
        put("chars", a.toString())
    }

    fun loadScenes(): List<Scene> {
        val a = JSONArray(s("scenes", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val clip = o.optString("clip").ifBlank { null }
            Scene(
                o.getInt("id"), o.getString("text"), o.getString("camera"), o.optBoolean("chain", true),
                clip, if (clip != null) "Ready" else "Not generated"
            )
        }
    }

    fun saveScenes(l: List<Scene>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("text", it.text).put("camera", it.camera)
                .put("chain", it.chain).put("clip", it.clipPath ?: ""))
        }
        put("scenes", a.toString())
    }
}
