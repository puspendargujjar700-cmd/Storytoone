package com.storytoons.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Locale

private val Ink = Color(0xFF0E1412)
private val Moss = Color(0xFF1F3A2E)
private val Lantern = Color(0xFFE0A43A)
private val Bone = Color(0xFFE9E4D4)
private val Blood = Color(0xFFB3402F)

private val scheme = darkColorScheme(
    primary = Lantern, onPrimary = Ink,
    secondary = Moss, onSecondary = Bone,
    background = Ink, onBackground = Bone,
    surface = Color(0xFF16201C), onSurface = Bone,
    surfaceVariant = Moss, onSurfaceVariant = Bone,
    error = Blood
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        setContent { MaterialTheme(colorScheme = scheme) { App() } }
    }
}

private fun usd(v: Float) = String.format(Locale.US, "$%.2f", v)

@Composable
fun App(vm: AppVM = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Story", "World", "Settings")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(listOf("✎", "☻", "⚙")[i]) },
                        label = { Text(t) }
                    )
                }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> StoryScreen(vm, pad)
            1 -> WorldScreen(vm, pad)
            else -> SettingsScreen(vm, pad)
        }
    }
}

@Composable
fun StoryScreen(vm: AppVM, pad: PaddingValues) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf<Int?>(null) } // -1 = all, else count

    confirm?.let { c ->
        val n = if (c < 0) vm.pending() else minOf(c, vm.pending())
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Generate $n clips?") },
            text = {
                Text("Estimated cost ${usd(vm.estimate(n))} (about ${n * CLIP_SECONDS} sec of video). " +
                    "Already spent ${usd(vm.spent)}, limit ${vm.limit} USD. " +
                    "Keep the phone connected to the internet.")
            },
            confirmButton = {
                TextButton(onClick = { vm.generate(if (c < 0) null else c); confirm = null }) { Text("Start") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }

    LazyColumn(
        Modifier.padding(pad).padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Spacer(Modifier.height(12.dp)) }
        item {
            OutlinedTextField(
                value = vm.story, onValueChange = vm::setStoryText,
                label = { Text("Paste your story") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp)
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = vm.minutes, onValueChange = vm::setMinutesText,
                    label = { Text("Minutes") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.width(110.dp)
                )
                Styles.all.keys.forEach { name ->
                    FilterChip(selected = vm.style == name, onClick = { vm.setStyleChoice(name) },
                        label = { Text(name) })
                }
            }
        }
        item {
            Button(onClick = vm::planScenes, enabled = vm.story.isNotBlank() && !vm.running) {
                Text("Build story world and scenes")
            }
        }
        if (vm.message.isNotBlank()) item { Text(vm.message, style = MaterialTheme.typography.bodyMedium) }

        if (vm.scenes.isNotEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${vm.scenes.size} scenes, about ${vm.scenes.size * CLIP_SECONDS / 60} min", fontWeight = FontWeight.Bold)
                        Text("Remaining ${vm.pending()} clips, estimate ${usd(vm.estimate(vm.pending()))}")
                        Text("Spent so far ${usd(vm.spent)}, limit ${vm.limit} USD")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { confirm = 3 }, enabled = !vm.running && vm.pending() > 0) { Text("Test 3 clips") }
                            Button(onClick = { confirm = -1 }, enabled = !vm.running && vm.pending() > 0) { Text("Generate all") }
                        }
                        if (vm.running) {
                            LinearProgressIndicator(Modifier.fillMaxWidth())
                            OutlinedButton(onClick = vm::stop) { Text("Stop") }
                        }
                        Button(onClick = vm::joinClips, enabled = !vm.running) { Text("Join clips into one MP4") }
                    }
                }
            }
        }
        vm.finalPath?.let { path ->
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Final video", fontWeight = FontWeight.Bold, color = Lantern)
                    VideoPlayer(Uri.fromFile(File(path)))
                    vm.finalUri?.let { u ->
                        TextButton(onClick = {
                            try {
                                ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                            } catch (e: Exception) { }
                        }) { Text("Open in gallery") }
                    }
                }
            }
        }
        items(vm.scenes, key = { it.id }) { SceneCard(vm, it) }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun SceneCard(vm: AppVM, sc: Scene) {
    val hasClip = sc.clipPath?.let { File(it).exists() } == true
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Scene ${sc.id + 1}", fontWeight = FontWeight.Bold, color = Lantern)
            Text(sc.text)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sc.camera, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.nextCamera(sc.id) }) { Text("Change camera") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = sc.chain, onCheckedChange = { vm.toggleChain(sc.id) })
                Spacer(Modifier.width(8.dp))
                Text("Continue from previous clip", style = MaterialTheme.typography.bodySmall)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.generateSingle(sc.id) }, enabled = !sc.busy && !vm.running) {
                    Text(if (hasClip) "Redo" else "Generate")
                }
                if (hasClip) {
                    OutlinedButton(onClick = { vm.previewId = if (vm.previewId == sc.id) null else sc.id }) {
                        Text(if (vm.previewId == sc.id) "Hide" else "Play")
                    }
                }
            }
            Text(sc.status, style = MaterialTheme.typography.bodySmall)
            if (sc.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            sc.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            if (hasClip && vm.previewId == sc.id) VideoPlayer(Uri.fromFile(File(sc.clipPath!!)))
        }
    }
}

@Composable
fun VideoPlayer(uri: Uri) {
    val ctx = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare() }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().height(420.dp)
    )
}

@Composable
fun WorldScreen(vm: AppVM, pad: PaddingValues) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    LazyColumn(
        Modifier.padding(pad).padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Spacer(Modifier.height(12.dp)) }
        item {
            Text(
                "This is your story bible. Every clip gets this world and these character looks in its prompt, which keeps characters consistent. Edit anything that looks wrong before generating.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        item {
            OutlinedTextField(vm.world, vm::setWorldText, label = { Text("World, style, lighting") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp))
        }
        items(vm.characters, key = { it.id }) { c ->
            var d by remember(c.id) { mutableStateOf(c.desc) }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(c.name, fontWeight = FontWeight.Bold, color = Lantern)
                    OutlinedTextField(d, { d = it; vm.editCharacter(c, it) }, label = { Text("Look") },
                        modifier = Modifier.fillMaxWidth())
                    TextButton(onClick = { vm.removeCharacter(c) }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                }
            }
        }
        item { Text("Add a character", fontWeight = FontWeight.Bold) }
        item { OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth()) }
        item {
            OutlinedTextField(desc, { desc = it }, label = { Text("Look (age, face, hair, clothes)") },
                modifier = Modifier.fillMaxWidth())
        }
        item {
            Button(onClick = { vm.addCharacter(name, desc); name = ""; desc = "" }, enabled = name.isNotBlank()) {
                Text("Add character")
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun SettingsScreen(vm: AppVM, pad: PaddingValues) {
    var saved by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.padding(pad).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Google Gemini API", style = MaterialTheme.typography.titleMedium) }
        item {
            Text("Get a key at aistudio.google.com/apikey. It stays on this phone. Never share it.",
                style = MaterialTheme.typography.bodyMedium)
        }
        item {
            OutlinedTextField(vm.apiKey, { vm.apiKey = it; saved = false }, label = { Text("API key") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.videoModel, { vm.videoModel = it; saved = false }, label = { Text("Video model") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.textModel, { vm.textModel = it; saved = false }, label = { Text("Story planning model") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.resolution, { vm.resolution = it; saved = false },
                label = { Text("Resolution (360p = cheap test, 720p = final)") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.price, { vm.price = it; saved = false }, label = { Text("Price per video second (USD)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.limit, { vm.limit = it; saved = false }, label = { Text("Spend limit (USD)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.baseUrl, { vm.baseUrl = it; saved = false }, label = { Text("API base URL") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.saveSettings(); saved = true }) { Text("Save settings") }
                OutlinedButton(onClick = vm::resetSpent) { Text("Reset spent counter") }
            }
        }
        if (saved) item { Text("Saved", color = Lantern) }
    }
}
