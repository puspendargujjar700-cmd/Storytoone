package com.storytoons.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File

private val Ink = Color(0xFF0E1412)
private val Moss = Color(0xFF1F3A2E)
private val Lantern = Color(0xFFE0A43A)
private val Bone = Color(0xFFE9E4D4)
private val Blood = Color(0xFFB3402F)

private val scheme = darkColorScheme(
    primary = Lantern, onPrimary = Ink,
    secondary = Moss, onSecondary = Bone,
    background = Ink, onBackground = Bone,
    surface = Color(0xFF16201C), onSurface = Bone,
    surfaceVariant = Moss, onSurfaceVariant = Bone,
    error = Blood
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        setContent { MaterialTheme(colorScheme = scheme) { App() } }
    }
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("prompt", text))
}

fun readClipboard(ctx: Context): String {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = cm.primaryClip
    if (clip == null || clip.itemCount == 0) return ""
    return clip.getItemAt(0).coerceToText(ctx)?.toString().orEmpty()
}

/** Copies the text and sends it straight to the Gemini app (falls back to just copying). */
fun openGemini(ctx: Context, text: String) {
    copyText(ctx, text)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
        setPackage("com.google.android.apps.bard")
    }
    try {
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Prompt copy ho gaya. Gemini app kholke paste karo.", Toast.LENGTH_LONG).show()
    }
}

@Composable
fun App(vm: AppVM = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Story", "World", "Settings")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(listOf("✎", "☻", "⚙")[i]) },
                        label = { Text(t) }
                    )
                }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> StoryScreen(vm, pad)
            1 -> WorldScreen(vm, pad)
            else -> SettingsScreen(vm, pad)
        }
    }
}

@Composable
fun FileImage(path: String?, modifier: Modifier = Modifier) {
    val stamp = path?.let { File(it).lastModified() }
    val bmp = remember(path, stamp) {
        path?.let {
            val o = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapFactory.decodeFile(it, o)?.asImageBitmap()
        }
    }
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, modifier = modifier, contentScale = ContentScale.Fit)
    }
}

@Composable
fun StoryScreen(vm: AppVM, pad: PaddingValues) {
    val ctx = LocalContext.current
    val busy = vm.running || vm.building
    LazyColumn(
        Modifier.padding(pad).padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Spacer(Modifier.height(12.dp)) }
        item {
            OutlinedTextField(
                value = vm.story, onValueChange = vm::setStoryText,
                label = { Text("Paste your story") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp)
            )
        }
        item {
            OutlinedTextField(
                value = vm.minutes, onValueChange = vm::setMinutesText,
                label = { Text("Video length (minutes)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Styles.all.keys.forEach { name ->
                    FilterChip(selected = vm.style == name, onClick = { vm.setStyleChoice(name) },
                        label = { Text(name, maxLines = 1) })
                }
            }
        }
        item { Text("Free way (your Gemini subscription)", fontWeight = FontWeight.Bold, color = Lantern) }
        item {
            Button(onClick = { openGemini(ctx, vm.planPromptText()) }, enabled = vm.story.isNotBlank() && !busy) {
                Text("1. Send story to Gemini app")
            }
        }
        item {
            Text("Gemini will reply with a plan. Tap its copy button, come back here and press 2.",
                style = MaterialTheme.typography.bodySmall)
        }
        item {
            Button(onClick = { vm.applyPlanJson(readClipboard(ctx)) }, enabled = !busy) {
                Text("2. Paste Gemini's plan")
            }
        }
        item { Text("Only if you have a paid API key", style = MaterialTheme.typography.bodySmall) }
        item {
            OutlinedButton(onClick = vm::buildWorld, enabled = vm.story.isNotBlank() && !busy) {
                Text("Build story world with API")
            }
        }
        if (vm.building) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (vm.message.isNotBlank()) item { Text(vm.message, style = MaterialTheme.typography.bodyMedium) }

        if (vm.scenes.isNotEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${vm.scenes.size} scenes, about ${vm.scenes.size * CLIP_SECONDS} sec of video", fontWeight = FontWeight.Bold)
                        Text("Clips ready: ${vm.ready()} / ${vm.scenes.size}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { vm.generate(3) }, enabled = !busy && vm.pending() > 0) { Text("Test 3 clips") }
                            Button(onClick = { vm.generate(null) }, enabled = !busy && vm.pending() > 0) { Text("Generate all") }
                        }
                        if (vm.running) {
                            LinearProgressIndicator(Modifier.fillMaxWidth())
                            OutlinedButton(onClick = vm::stop) { Text("Stop") }
                        }
                        Button(onClick = vm::joinClips, enabled = !busy && vm.ready() > 0) { Text("Join clips into one MP4") }
                    }
                }
            }
        }
        vm.finalPath?.let { path ->
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Final video", fontWeight = FontWeight.Bold, color = Lantern)
                    VideoPlayer(Uri.fromFile(File(path)))
                    vm.finalUri?.let { u ->
                        TextButton(onClick = {
                            try {
                                ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                            } catch (e: Exception) { }
                        }) { Text("Open in gallery") }
                    }
                }
            }
        }
        items(vm.scenes, key = { it.id }) { SceneCard(vm, it) }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun SceneCard(vm: AppVM, sc: Scene) {
    val hasClip = sc.clipPath?.let { File(it).exists() } == true
    val ctx = LocalContext.current
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.importClip(sc.id, uri)
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Scene ${sc.id + 1}", fontWeight = FontWeight.Bold, color = Lantern)
            Text(sc.text)
            if (sc.location.isNotBlank() || sc.chars.isNotEmpty()) {
                Text("Place: ${sc.location.ifBlank { "-" }}   Characters: ${sc.chars.joinToString().ifBlank { "-" }}",
                    style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sc.camera, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.nextCamera(sc.id) }) { Text("Change camera") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { openGemini(ctx, vm.clipPromptText(sc)) }) { Text("Prompt to Gemini") }
                OutlinedButton(onClick = { importer.launch("video/*") }) { Text("Import clip") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.generateSingle(sc.id) },
                    enabled = !sc.busy && !vm.running && !vm.building) {
                    Text(if (hasClip) "Redo (API)" else "Generate (API)")
                }
                if (hasClip) {
                    OutlinedButton(onClick = { vm.previewId = if (vm.previewId == sc.id) null else sc.id }) {
                        Text(if (vm.previewId == sc.id) "Hide" else "Play")
                    }
                }
            }
            Text(sc.status, style = MaterialTheme.typography.bodySmall)
            if (sc.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            sc.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            if (hasClip && vm.previewId == sc.id) VideoPlayer(Uri.fromFile(File(sc.clipPath!!)))
        }
    }
}

@Composable
fun VideoPlayer(uri: Uri) {
    val ctx = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare() }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().height(420.dp)
    )
}

@Composable
fun WorldScreen(vm: AppVM, pad: PaddingValues) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    val busy = vm.running || vm.building
    LazyColumn(
        Modifier.padding(pad).padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Spacer(Modifier.height(12.dp)) }
        item {
            Text(
                "This is your story world. Every clip gets these character sheets (front, back and side views) and place images as references, so characters and backgrounds stay the same. You can change any image or description.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        if (vm.message.isNotBlank()) item { Text(vm.message, color = Lantern) }
        item {
            OutlinedTextField(vm.world, vm::setWorldText, label = { Text("World, style, lighting") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp))
        }
        if (vm.places.isNotEmpty()) item { Text("Places", fontWeight = FontWeight.Bold) }
        items(vm.places, key = { it.id }) { pl -> PlaceCard(vm, pl, busy) }
        if (vm.characters.isNotEmpty()) item { Text("Characters", fontWeight = FontWeight.Bold) }
        items(vm.characters, key = { it.id }) { c -> CharacterCard(vm, c, busy) }
        item { Text("Add a character", fontWeight = FontWeight.Bold) }
        item { OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth()) }
        item {
            OutlinedTextField(desc, { desc = it }, label = { Text("Look (age, face, hair, clothes)") },
                modifier = Modifier.fillMaxWidth())
        }
        item {
            Button(onClick = { vm.addCharacter(name, desc); name = ""; desc = "" }, enabled = name.isNotBlank()) {
                Text("Add character")
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun PlaceCard(vm: AppVM, pl: Place, busy: Boolean) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setPlaceImage(pl, uri)
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(pl.name, fontWeight = FontWeight.Bold, color = Lantern)
            FileImage(pl.imagePath, Modifier.fillMaxWidth().heightIn(max = 260.dp))
            Text(pl.desc, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { openGemini(ctx, vm.placePromptText(pl)) }) { Text("Prompt to Gemini") }
                OutlinedButton(onClick = { picker.launch("image/*") }) { Text("Use my image") }
            }
            OutlinedButton(onClick = { vm.regenPlace(pl) }, enabled = !busy) { Text("Create image (API)") }
        }
    }
}

@Composable
fun CharacterCard(vm: AppVM, c: Character, busy: Boolean) {
    val ctx = LocalContext.current
    var d by remember(c.id) { mutableStateOf(c.desc) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.pickSheet(c, uri)
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(c.name, fontWeight = FontWeight.Bold, color = Lantern)
            FileImage(c.sheetPath, Modifier.fillMaxWidth().heightIn(max = 260.dp))
            if (c.voice.isNotBlank()) Text("Voice: ${c.voice}", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(d, { d = it; vm.editCharacter(c, it) }, label = { Text("Look") },
                modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { openGemini(ctx, vm.sheetPromptText(c)) }) { Text("Sheet prompt to Gemini") }
                OutlinedButton(onClick = { picker.launch("image/*") }) { Text("Use my image") }
            }
            OutlinedButton(onClick = { vm.regenSheet(c) }, enabled = !busy) {
                Text(if (c.sheetPath == null) "Create sheet (API)" else "Regenerate (API)")
            }
            TextButton(onClick = { vm.removeCharacter(c) }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppVM, pad: PaddingValues) {
    var saved by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.padding(pad).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Google Gemini", style = MaterialTheme.typography.titleMedium) }
        item {
            Text("Get your key at aistudio.google.com/apikey and paste it here. It stays on this phone. Never share it.",
                style = MaterialTheme.typography.bodyMedium)
        }
        item {
            OutlinedTextField(vm.apiKey, { vm.apiKey = it; saved = false }, label = { Text("API key") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.resolution, { vm.resolution = it; saved = false },
                label = { Text("Video quality (360p test, 720p final)") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.videoModel, { vm.videoModel = it; saved = false }, label = { Text("Video model") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.imageModel, { vm.imageModel = it; saved = false }, label = { Text("Image model") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.textModel, { vm.textModel = it; saved = false }, label = { Text("Story planning model") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item {
            OutlinedTextField(vm.baseUrl, { vm.baseUrl = it; saved = false }, label = { Text("API base URL") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        item { Button(onClick = { vm.saveSettings(); saved = true }) { Text("Save settings") } }
        if (saved) item { Text("Saved", color = Lantern) }
    }
}
