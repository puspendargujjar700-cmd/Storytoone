package com.storytoons.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import java.io.File

private val Ink = Color(0xFF0E1412)
private val Moss = Color(0xFF1F3A2E)
private val Lantern = Color(0xFFE0A43A)
private val Bone = Color(0xFFE9E4D4)
private val Blood = Color(0xFFB3402F)

private val scheme = darkColorScheme(
    primary = Lantern, onPrimary = Ink,
    secondary = Moss, onSecondary = Bone,
    background = Ink, onBackground = Bone,
    surface = Color(0xFF16201C), onSurface = Bone,
    surfaceVariant = Moss, onSurfaceVariant = Bone,
    error = Blood
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = scheme) { App() } }
    }
}

@Composable
fun App(vm: AppVM = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Story", "Characters", "Settings")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(listOf("✎", "☻", "⚙")[i]) },
                        label = { Text(t) }
                    )
                }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> StoryScreen(vm, pad)
            1 -> CharactersScreen(vm, pad)
            else -> SettingsScreen(vm, pad)
        }
    }
}

@Composable
fun StoryScreen(vm: AppVM, pad: PaddingValues) {
    LazyColumn(
        Modifier.padding(pad).padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Spacer(Modifier.height(12.dp)) }
        item {
            OutlinedTextField(
                value = vm.story, onValueChange = vm::setStoryText,
                label = { Text("Paste your story") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp)
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Styles.all.keys.forEach { name ->
                    FilterChip(
                        selected = vm.style == name,
                        onClick = { vm.setStyleChoice(name) },
                        label = { Text(name) }
                    )
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = vm::splitScenes, enabled = vm.story.isNotBlank()) { Text("Split into scenes") }
                OutlinedButton(onClick = vm::generateAll, enabled = vm.scenes.isNotEmpty()) { Text("Generate all") }
            }
        }
        if (vm.scenes.isEmpty()) {
            item {
                Text(
                    "Paste a story and tap Split into scenes. Each scene becomes one video clip of about 8 seconds.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        items(vm.scenes, key = { it.id }) { SceneCard(vm, it) }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun SceneCard(vm: AppVM, sc: Scene) {
    val ctx = LocalContext.current
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Scene ${sc.id + 1}", fontWeight = FontWeight.Bold, color = Lantern)
            Text(sc.text)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sc.camera, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.nextCamera(sc.id) }) { Text("Change camera") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.generate(sc.id) }, enabled = !sc.busy) {
                    Text(if (sc.videoUrl == null) "Generate video" else "Generate again")
                }
                OutlinedButton(onClick = { vm.narrate(sc.text) }) { Text("Voice preview") }
            }
            Text(sc.status, style = MaterialTheme.typography.bodySmall)
            if (sc.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            sc.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            sc.videoUrl?.let { url ->
                VideoPlayer(url)
                TextButton(onClick = {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }) { Text("Open to download") }
            }
        }
    }
}

@Composable
fun VideoPlayer(url: String) {
    val ctx = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(url)); prepare()
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().height(420.dp)
    )
}

@Composable
fun CharactersScreen(vm: AppVM, pad: PaddingValues) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    LazyColumn(
        Modifier.padding(pad).padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Spacer(Modifier.height(12.dp)) }
        item {
            Text(
                "Add each character with a short look description. Then attach one character sheet image showing front, back, left and right views, so the video keeps the same look from every angle.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        item {
            OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
        }
        item {
            OutlinedTextField(desc, { desc = it }, label = { Text("Look (age, clothes, hair)") },
                modifier = Modifier.fillMaxWidth())
        }
        item {
            Button(onClick = { vm.addCharacter(name, desc); name = ""; desc = "" }, enabled = name.isNotBlank()) {
                Text("Add character")
            }
        }
        items(vm.characters, key = { it.id }) { c -> CharacterCard(vm, c) }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun CharacterCard(vm: AppVM, c: Character) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setSheet(c, uri)
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(c.name, fontWeight = FontWeight.Bold, color = Lantern)
            if (c.desc.isNotBlank()) Text(c.desc)
            c.sheetPath?.let {
                AsyncImage(model = File(it), contentDescription = "${c.name} character sheet",
                    modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { picker.launch("image/*") }) {
                    Text(if (c.sheetPath == null) "Attach character sheet" else "Replace sheet")
                }
                TextButton(onClick = { vm.removeCharacter(c) }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppVM, pad: PaddingValues) {
    var saved by remember { mutableStateOf(false) }
    Column(
        Modifier.padding(pad).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Video generation", style = MaterialTheme.typography.titleMedium)
        Text(
            "Seedance 2.5 runs through a paid API provider. Paste your provider's API key. It stays on this phone.",
            style = MaterialTheme.typography.bodyMedium
        )
        OutlinedTextField(vm.apiKey, { vm.apiKey = it; saved = false }, label = { Text("API key") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(vm.baseUrl, { vm.baseUrl = it; saved = false }, label = { Text("API base URL") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(vm.modelRef, { vm.modelRef = it; saved = false },
            label = { Text("Model id (with character sheets)") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(vm.modelTxt, { vm.modelTxt = it; saved = false },
            label = { Text("Model id (text only)") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = { vm.saveSettings(); saved = true }) { Text("Save settings") }
        if (saved) Text("Saved", color = Lantern)
    }
}
