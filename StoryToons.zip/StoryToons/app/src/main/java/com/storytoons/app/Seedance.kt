package com.storytoons.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.TimeUnit

object Seedance {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    fun imageToDataUri(path: String, maxSide: Int = 1024): String? {
        val f = File(path)
        if (!f.exists()) return null
        val bmp = BitmapFactory.decodeFile(path) ?: return null
        val scale = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
        val out = if (scale < 1f)
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        else bmp
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 85, bos)
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    /** Submits a job, polls until a video URL shows up, returns that URL. */
    suspend fun generate(
        store: Store,
        prompt: String,
        refs: List<String>,
        seconds: Int = 8
    ): String = withContext(Dispatchers.IO) {
        require(store.apiKey.isNotBlank()) { "Settings mein API key daalo." }
        val base = store.baseUrl.trimEnd('/')
        val model = if (refs.isEmpty()) store.modelTextOnly else store.modelWithRefs

        val body = JSONObject()
            .put("model", model)
            .put("prompt", prompt)
            .put("duration", seconds)
            .put("aspect_ratio", "9:16")
            .put("resolution", "720p")
            .put("generate_audio", true)
        if (refs.isNotEmpty()) body.put("reference_images", JSONArray(refs))

        val submit = Request.Builder()
            .url("$base/generateVideo")
            .header("Authorization", "Bearer ${store.apiKey}")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val submitText = http.newCall(submit).execute().use {
            val t = it.body?.string().orEmpty()
            if (!it.isSuccessful) error("Server ne mana kiya (${it.code}): ${t.take(300)}")
            t
        }
        findVideoUrl(submitText)?.let { return@withContext it }
        val id = findId(submitText) ?: error("Job id nahi mila: ${submitText.take(300)}")

        repeat(120) {
            delay(5000)
            val poll = Request.Builder()
                .url("$base/prediction/$id")
                .header("Authorization", "Bearer ${store.apiKey}")
                .build()
            val text = http.newCall(poll).execute().use { r -> r.body?.string().orEmpty() }
            findVideoUrl(text)?.let { return@withContext it }
            val low = text.lowercase().replace(" ", "")
            if ("\"status\":\"failed\"" in low || "\"status\":\"error\"" in low) {
                error("Generation fail hui: ${text.take(300)}")
            }
        }
        error("10 minute mein video ready nahi hui.")
    }

    private fun findVideoUrl(raw: String): String? =
        Regex("https?:[^\"\\s]+?\\.(mp4|webm|mov)[^\"\\s]*")
            .find(raw.replace("\\/", "/"))?.value

    private fun findId(raw: String): String? = try {
        val j = JSONObject(raw)
        j.optString("prediction_id").ifBlank {
            j.optJSONObject("data")?.let { d ->
                d.optString("id").ifBlank { d.optString("prediction_id") }
            } ?: j.optString("id")
        }.ifBlank { null }
    } catch (e: Exception) { null }
}
