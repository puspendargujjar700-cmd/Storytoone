package com.storytoons.app

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class AppVM(private val app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    var story by mutableStateOf(store.story)
    var minutes by mutableStateOf(store.minutes.toString())
    var style by mutableStateOf(store.style)
    var world by mutableStateOf(store.world)
    val scenes = mutableStateListOf<Scene>().apply { addAll(store.loadScenes()) }
    val characters = mutableStateListOf<Character>().apply { addAll(store.loadCharacters()) }
    val places = mutableStateListOf<Place>().apply { addAll(store.loadPlaces()) }

    var apiKey by mutableStateOf(store.apiKey)
    var baseUrl by mutableStateOf(store.baseUrl)
    var videoModel by mutableStateOf(store.videoModel)
    var textModel by mutableStateOf(store.textModel)
    var imageModel by mutableStateOf(store.imageModel)
    var resolution by mutableStateOf(store.resolution)

    var running by mutableStateOf(false)
    var building by mutableStateOf(false)
    var message by mutableStateOf("")
    var previewId by mutableStateOf<Int?>(null)
    var finalPath by mutableStateOf<String?>(null)
    var finalUri by mutableStateOf<Uri?>(null)

    private var job: Job? = null
    private val clipsDir get() = File(app.filesDir, "clips").apply { mkdirs() }
    private val assetsDir get() = File(app.filesDir, "assets").apply { mkdirs() }

    private fun hasClip(i: Int) = scenes[i].clipPath?.let { File(it).exists() } == true
    fun ready() = scenes.indices.count { hasClip(it) }
    fun pending() = scenes.size - ready()

    fun saveSettings() {
        store.apiKey = apiKey.trim()
        store.baseUrl = baseUrl.trim()
        store.videoModel = videoModel.trim()
        store.textModel = textModel.trim()
        store.imageModel = imageModel.trim()
        store.resolution = resolution.trim().ifBlank { "720p" }
    }

    fun setStoryText(t: String) { story = t; store.story = t }
    fun setMinutesText(t: String) { minutes = t.filter { it.isDigit() }.take(3); store.minutes = minutes.toIntOrNull() ?: 1 }
    fun setStyleChoice(n: String) { style = n; store.style = n }
    fun setWorldText(t: String) { world = t; store.world = t }

    private fun persist() {
        store.saveScenes(scenes); store.saveCharacters(characters); store.savePlaces(places)
    }

    private fun startKeepAlive() =
        ContextCompat.startForegroundService(app, Intent(app, KeepAliveService::class.java))
    private fun stopKeepAlive() { app.stopService(Intent(app, KeepAliveService::class.java)) }

    // ================================================================ world building
    fun buildWorld() {
        if (running || building) return
        job = viewModelScope.launch {
            building = true; startKeepAlive(); message = "Story world bana raha hoon..."
            try {
                val n = ((minutes.toIntOrNull() ?: 1) * 60 / CLIP_SECONDS).coerceIn(1, 200)
                var planned = false
                try {
                    val plan = Veo.planStory(store, story, n, Styles.all[style] ?: "")
                    applyPlan(plan)
                    planned = true
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    localSplit()
                    message = "AI planning fail hui (${e.message?.take(160)}). Simple split use kiya."
                }
                persist()
                if (planned) {
                    var lastErr = ""
                    val failed = mutableListOf<String>()
                    for ((i, c) in characters.toList().withIndex()) {
                        message = "Character sheet ${i + 1}/${characters.size}: ${c.name}..."
                        makeSheet(c)?.let { failed += c.name; lastErr = it }
                    }
                    for ((i, pl) in places.toList().withIndex()) {
                        message = "Place image ${i + 1}/${places.size}: ${pl.name}..."
                        makePlaceImage(pl)?.let { failed += pl.name; lastErr = it }
                    }
                    message = if (failed.isEmpty())
                        "World ready: ${characters.size} characters, ${places.size} places, ${scenes.size} scenes. World tab mein dekh lo."
                    else "World bana, par ye images nahi bani: ${failed.joinToString()}. ($lastErr) World tab mein Regenerate dabao."
                }
            } finally {
                building = false; stopKeepAlive(); persist()
            }
        }
    }

    private fun localSplit() {
        val chunks = mutableListOf<String>()
        story.split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }.forEach { para ->
            if (para.length <= 260) chunks += para else {
                var cur = ""
                para.split(Regex("(?<=[.!?।])\\s+")).forEach { sent ->
                    if (cur.isNotEmpty() && cur.length + sent.length > 260) { chunks += cur; cur = sent }
                    else cur = if (cur.isEmpty()) sent else "$cur $sent"
                }
                if (cur.isNotEmpty()) chunks += cur
            }
        }
        characters.clear(); places.clear(); scenes.clear()
        chunks.forEachIndexed { i, t -> scenes += Scene(i, t, Cameras.all[i % Cameras.all.size]) }
    }

    fun sheetPrompt(c: Character) =
        "${Styles.all[style]}. Character design turnaround sheet of ${c.name}: ${c.desc}. " +
        "Show the same character four times in one wide image, full body, side by side: front view, back view, " +
        "left side view, right side view. Identical face, hair, outfit and proportions in every view. " +
        "Plain neutral background, no text, no labels."

    fun placePrompt(p: Place) =
        "${Styles.all[style]}. ${world.take(300)}. Wide establishing background image of the location " +
        "\"${p.name}\": ${p.desc}. Vertical 9:16 composition. No people, no characters, no text."

    /** Returns null on success or the error text. */
    private suspend fun makeSheet(c: Character): String? = try {
        val bytes = Veo.generateImage(store, sheetPrompt(c))
        val f = File(assetsDir, "char_${c.id}_${System.currentTimeMillis()}.jpg")
        withContext(Dispatchers.IO) { Media.saveJpeg(bytes, f) }
        val i = characters.indexOfFirst { it.id == c.id }
        if (i >= 0) { characters[i].sheetPath?.let { File(it).delete() }; characters[i] = characters[i].copy(sheetPath = f.absolutePath) }
        persist(); null
    } catch (e: CancellationException) { throw e } catch (e: Exception) { e.message ?: e.toString() }

    private suspend fun makePlaceImage(p: Place): String? = try {
        val bytes = Veo.generateImage(store, placePrompt(p))
        val f = File(assetsDir, "place_${p.id}_${System.currentTimeMillis()}.jpg")
        withContext(Dispatchers.IO) { Media.saveJpeg(bytes, f) }
        val i = places.indexOfFirst { it.id == p.id }
        if (i >= 0) { places[i].imagePath?.let { File(it).delete() }; places[i] = places[i].copy(imagePath = f.absolutePath) }
        persist(); null
    } catch (e: CancellationException) { throw e } catch (e: Exception) { e.message ?: e.toString() }

    fun regenSheet(c: Character) {
        if (running || building) return
        viewModelScope.launch {
            building = true; message = "${c.name} ki image bana raha hoon..."
            try { message = makeSheet(c)?.let { "Image fail: $it" } ?: "${c.name} ki image ready." }
            finally { building = false }
        }
    }

    fun regenPlace(p: Place) {
        if (running || building) return
        viewModelScope.launch {
            building = true; message = "${p.name} ki image bana raha hoon..."
            try { message = makePlaceImage(p)?.let { "Image fail: $it" } ?: "${p.name} ki image ready." }
            finally { building = false }
        }
    }

    fun pickSheet(c: Character, uri: Uri) {
        try {
            val bytes = app.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
            val f = File(assetsDir, "char_${c.id}_${System.currentTimeMillis()}.jpg")
            Media.saveJpeg(bytes, f)
            val i = characters.indexOfFirst { it.id == c.id }
            if (i >= 0) characters[i] = characters[i].copy(sheetPath = f.absolutePath)
            persist()
        } catch (e: Exception) { message = "Image lagane mein dikkat: ${e.message}" }
    }

    fun addCharacter(name: String, desc: String) {
        characters += Character(UUID.randomUUID().toString(), name.trim(), desc.trim()); persist()
    }
    fun editCharacter(c: Character, desc: String) {
        val i = characters.indexOfFirst { it.id == c.id }
        if (i >= 0) characters[i] = characters[i].copy(desc = desc)
        persist()
    }
    fun removeCharacter(c: Character) { characters.remove(c); persist() }

    // ================================================================ scenes
    private fun update(id: Int, f: (Scene) -> Scene) {
        val i = scenes.indexOfFirst { it.id == id }
        if (i >= 0) scenes[i] = f(scenes[i])
    }

    fun nextCamera(id: Int) {
        update(id) { it.copy(camera = Cameras.all[(Cameras.all.indexOf(it.camera) + 1) % Cameras.all.size]) }
        persist()
    }

    private fun readIf(path: String?): ByteArray? =
        path?.let { File(it) }?.takeIf { it.exists() }?.readBytes()

    /** Builds the prompt and the list of reference images (tags <IMAGE_REF_n> match the list order). */
    private fun clipInputs(sc: Scene, useRefs: Boolean = true): Pair<String, List<ByteArray>> {
        val refs = mutableListOf<ByteArray>()
        val sb = StringBuilder()
        sb.append(Styles.all[style] ?: "").append(". ")
        if (world.isNotBlank()) sb.append(world.take(500)).append(". ")
        sb.append("Vertical 9:16. ")

        val inScene = characters.filter { c -> sc.chars.any { it.equals(c.name, ignoreCase = true) } }
            .ifEmpty { characters }.take(3)
        inScene.forEach { c ->
            val bytes = if (useRefs) readIf(c.sheetPath) else null
            if (bytes != null) {
                sb.append("${c.name} is the character shown in <IMAGE_REF_${refs.size}>. "); refs += bytes
            }
            sb.append("${c.name}: ${c.desc}.")
            if (c.voice.isNotBlank()) sb.append(" Voice: ${c.voice}.")
            sb.append(" ")
        }
        places.firstOrNull { it.name.equals(sc.location, ignoreCase = true) }?.let { pl ->
            val bytes = if (useRefs) readIf(pl.imagePath) else null
            if (bytes != null) {
                sb.append("Setting: ${pl.name}, exactly as in <IMAGE_REF_${refs.size}>. "); refs += bytes
            } else sb.append("Setting: ${pl.name}, ${pl.desc}. ")
        }
        if (refs.isNotEmpty()) {
            sb.append("Use the reference images only to keep every character and the setting identical from every angle (front, back, side); never show the reference sheets themselves. ")
        }
        sb.append("Camera: ${sc.camera}. ${sc.text} Single continuous shot, no scene cuts, about 8 seconds.")
        return sb.toString().take(3500) to refs
    }

    private suspend fun generateOne(idx: Int) {
        val sc = scenes[idx]
        update(sc.id) { it.copy(busy = true, status = "Generating (1-5 min)...", error = null) }
        try {
            val (prompt, refs) = clipInputs(sc)
            val out = File(clipsDir, "scene_${sc.id}.mp4")
            Veo.generateClip(store, prompt, refs, out)
            update(sc.id) { it.copy(busy = false, status = "Ready", clipPath = out.absolutePath) }
            persist()
        } catch (e: CancellationException) {
            update(sc.id) { it.copy(busy = false, status = "Stopped") }
            throw e
        } catch (e: Exception) {
            update(sc.id) { it.copy(busy = false, status = "Failed", error = e.message ?: e.toString()) }
        }
    }

    /** [limitCount] = how many new clips to make (null = all remaining). Up to 3 run at once. */
    fun generate(limitCount: Int?) {
        if (running || building) return
        job = viewModelScope.launch {
            running = true; startKeepAlive(); message = "Clips ban rahi hain..."
            try {
                val todo = scenes.indices.filter { !hasClip(it) }.let { if (limitCount != null) it.take(limitCount) else it }
                val sem = Semaphore(3)
                coroutineScope {
                    todo.forEach { idx -> launch { sem.withPermit { generateOne(idx) } } }
                }
                val ok = todo.count { hasClip(it) }
                val bad = todo.size - ok
                message = "Ho gaya: $ok clips bani" + if (bad > 0) ", $bad fail (scene card mein error dekho, phir Generate dabao)." else "."
            } finally {
                running = false; stopKeepAlive(); persist()
            }
        }
    }

    fun generateSingle(id: Int) {
        if (running || building) return
        job = viewModelScope.launch {
            running = true; startKeepAlive()
            try {
                val idx = scenes.indexOfFirst { it.id == id }
                if (idx >= 0) {
                    scenes[idx].clipPath?.let { File(it).delete() }
                    update(id) { it.copy(clipPath = null) }
                    generateOne(idx)
                }
            } finally { running = false; stopKeepAlive(); persist() }
        }
    }

    fun stop() { job?.cancel(); message = "Rok diya." }

    // ================================================================ subscription mode (Gemini app)
    private fun applyPlan(plan: Plan) {
        world = plan.world; store.world = plan.world
        characters.clear(); places.clear(); scenes.clear()
        plan.chars.forEach { characters += Character(UUID.randomUUID().toString(), it.name, it.look, it.voice) }
        plan.places.forEach { places += Place(UUID.randomUUID().toString(), it.name, it.look) }
        plan.scenes.forEachIndexed { i, s -> scenes += Scene(i, s.action, s.camera, s.location, s.chars) }
    }

    fun planPromptText(): String {
        val n = ((minutes.toIntOrNull() ?: 1) * 60 / CLIP_SECONDS).coerceIn(1, 200)
        return Veo.planInstruction(story, n, Styles.all[style] ?: "")
    }

    fun applyPlanJson(text: String) {
        try {
            applyPlan(Veo.parsePlan(text))
            persist()
            message = "Plan lag gaya: ${scenes.size} scenes, ${characters.size} characters, ${places.size} places. World tab dekho."
        } catch (e: Exception) {
            message = "Plan samajh nahi aaya (${e.message?.take(100)}). Gemini ka poora jawab copy karke dobara dabao."
        }
    }

    fun clipPromptText(sc: Scene) =
        "Generate a vertical 9:16 video with sound. " + clipInputs(sc, useRefs = false).first
    fun sheetPromptText(c: Character) = "Generate an image: " + sheetPrompt(c)
    fun placePromptText(p: Place) = "Generate an image: " + placePrompt(p)

    fun importClip(id: Int, uri: Uri) {
        viewModelScope.launch {
            try {
                val out = File(clipsDir, "scene_$id.mp4")
                withContext(Dispatchers.IO) {
                    app.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                }
                update(id) { it.copy(clipPath = out.absolutePath, status = "Imported", error = null) }
                persist()
            } catch (e: Exception) {
                update(id) { it.copy(error = "Import fail: ${e.message}") }
            }
        }
    }

    fun setPlaceImage(p: Place, uri: Uri) {
        try {
            val bytes = app.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
            val f = File(assetsDir, "place_${p.id}_${System.currentTimeMillis()}.jpg")
            Media.saveJpeg(bytes, f)
            val i = places.indexOfFirst { it.id == p.id }
            if (i >= 0) places[i] = places[i].copy(imagePath = f.absolutePath)
            persist()
        } catch (e: Exception) { message = "Image lagane mein dikkat: ${e.message}" }
    }

    // ================================================================ final video
    fun joinClips() {
        viewModelScope.launch {
            message = "Clips jod raha hoon..."
            try {
                val files = scenes.mapNotNull { s -> s.clipPath?.let { File(it) } }.filter { it.exists() }
                require(files.isNotEmpty()) { "Abhi koi clip nahi bani." }
                val dir = app.getExternalFilesDir(null) ?: app.filesDir
                val out = File(dir, "story_${System.currentTimeMillis()}.mp4")
                withContext(Dispatchers.IO) {
                    Media.concat(files, out)
                    finalUri = Media.saveToGallery(app, out)
                }
                finalPath = out.absolutePath
                val missing = scenes.size - files.size
                message = "Video ban gayi: ${files.size} clips, Movies/StoryToons mein save." +
                    if (missing > 0) " ($missing scenes ki clip baaki hai.)" else ""
            } catch (e: Exception) {
                message = "Jodna fail hua: ${e.message}"
            }
        }
    }
}
