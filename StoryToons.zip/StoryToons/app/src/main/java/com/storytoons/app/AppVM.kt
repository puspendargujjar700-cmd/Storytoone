package com.storytoons.app

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class AppVM(private val app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    var story by mutableStateOf(store.story)
    var minutes by mutableStateOf(store.minutes.toString())
    var style by mutableStateOf(store.style)
    var world by mutableStateOf(store.world)
    val scenes = mutableStateListOf<Scene>().apply { addAll(store.loadScenes()) }
    val characters = mutableStateListOf<Character>().apply { addAll(store.loadCharacters()) }

    var apiKey by mutableStateOf(store.apiKey)
    var baseUrl by mutableStateOf(store.baseUrl)
    var videoModel by mutableStateOf(store.videoModel)
    var textModel by mutableStateOf(store.textModel)
    var price by mutableStateOf(store.pricePerSec.toString())
    var limit by mutableStateOf(store.limitUsd.toString())
    var spent by mutableStateOf(store.spentUsd)

    var running by mutableStateOf(false)
    var message by mutableStateOf("")
    var previewId by mutableStateOf<Int?>(null)
    var finalPath by mutableStateOf<String?>(null)
    var finalUri by mutableStateOf<Uri?>(null)

    private var job: Job? = null
    private val clipsDir get() = File(app.filesDir, "clips").apply { mkdirs() }

    private fun priceF() = price.toFloatOrNull() ?: 0.05f
    private fun limitF() = limit.toFloatOrNull() ?: 10f
    fun clipCost() = CLIP_SECONDS * priceF()
    fun pending() = scenes.count { s -> s.clipPath?.let { File(it).exists() } != true }
    fun estimate(count: Int) = count * clipCost()

    fun saveSettings() {
        store.apiKey = apiKey.trim()
        store.baseUrl = baseUrl.trim()
        store.videoModel = videoModel.trim()
        store.textModel = textModel.trim()
        store.pricePerSec = priceF()
        store.limitUsd = limitF()
    }

    fun resetSpent() { spent = 0f; store.spentUsd = 0f }
    fun setStoryText(t: String) { story = t; store.story = t }
    fun setMinutesText(t: String) { minutes = t.filter { it.isDigit() }.take(3); store.minutes = minutes.toIntOrNull() ?: 1 }
    fun setStyleChoice(n: String) { style = n; store.style = n }
    fun setWorldText(t: String) { world = t; store.world = t }

    private fun persist() { store.saveScenes(scenes); store.saveCharacters(characters) }

    // ---------- planning ----------
    fun planScenes() {
        if (running) return
        viewModelScope.launch {
            message = "Story world bana raha hoon..."
            val n = ((minutes.toIntOrNull() ?: 1) * 60 / CLIP_SECONDS).coerceIn(1, 200)
            try {
                val plan = Veo.planStory(store, story, n, Styles.all[style] ?: "")
                world = plan.world; store.world = plan.world
                characters.clear()
                plan.characters.forEach { characters += Character(UUID.randomUUID().toString(), it.first, it.second) }
                scenes.clear()
                plan.scenes.forEachIndexed { i, s ->
                    scenes += Scene(i, s.action, s.camera, chain = i > 0 && !s.newLocation)
                }
                message = "${scenes.size} scenes ready. Characters tab mein look check kar lo."
            } catch (e: Exception) {
                localSplit()
                message = "AI planning fail hui (${e.message?.take(120)}). Simple split use kiya."
            }
            persist()
        }
    }

    private fun localSplit() {
        val chunks = mutableListOf<String>()
        story.split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }.forEach { para ->
            if (para.length <= 260) chunks += para else {
                var cur = ""
                para.split(Regex("(?<=[.!?।])\\s+")).forEach { sent ->
                    if (cur.isNotEmpty() && cur.length + sent.length > 260) { chunks += cur; cur = sent }
                    else cur = if (cur.isEmpty()) sent else "$cur $sent"
                }
                if (cur.isNotEmpty()) chunks += cur
            }
        }
        scenes.clear()
        chunks.forEachIndexed { i, t -> scenes += Scene(i, t, Cameras.all[i % Cameras.all.size], chain = i > 0) }
    }

    // ---------- scene edits ----------
    private fun update(id: Int, f: (Scene) -> Scene) {
        val i = scenes.indexOfFirst { it.id == id }
        if (i >= 0) scenes[i] = f(scenes[i])
    }

    fun nextCamera(id: Int) = update(id) {
        it.copy(camera = Cameras.all[(Cameras.all.indexOf(it.camera) + 1) % Cameras.all.size])
        .also { persistLater() }
    }
    fun toggleChain(id: Int) = update(id) { it.copy(chain = !it.chain) }.also { persistLater() }
    private fun persistLater() { viewModelScope.launch { kotlinx.coroutines.yield(); persist() } }

    fun addCharacter(name: String, desc: String) {
        characters += Character(UUID.randomUUID().toString(), name.trim(), desc.trim()); persist()
    }
    fun editCharacter(c: Character, desc: String) {
        val i = characters.indexOfFirst { it.id == c.id }
        if (i >= 0) characters[i] = c.copy(desc = desc); persist()
    }
    fun removeCharacter(c: Character) { characters.remove(c); persist() }

    // ---------- generation ----------
    fun buildPrompt(sc: Scene, hasStartImage: Boolean): String {
        val cast = characters.joinToString(" ") { "${it.name}: ${it.desc}." }.take(1500)
        return buildString {
            if (hasStartImage) append("Continue directly from the first frame, same characters and place. ")
            append(Styles.all[style] ?: "").append(". ")
            if (world.isNotBlank()) append(world.take(600)).append(". ")
            append("Vertical 9:16. ")
            if (cast.isNotBlank()) append("Characters, identical in every shot: $cast ")
            append("Camera: ${sc.camera}. ")
            append(sc.text)
        }.take(3500)
    }

    private suspend fun generateOne(idx: Int): Boolean {
        val sc = scenes[idx]
        val cost = clipCost()
        if (spent + cost > limitF()) {
            message = "Kharch limit (\$${limitF()}) pahunch gayi. Settings mein badha sakte ho."
            return false
        }
        update(sc.id) { it.copy(busy = true, status = "Generating (1-5 min)...", error = null) }
        return try {
            val out = File(clipsDir, "scene_${sc.id}.mp4")
            val startImg = if (sc.chain && idx > 0) {
                scenes[idx - 1].clipPath?.let { p ->
                    val f = File(p)
                    if (f.exists()) withContext(Dispatchers.IO) { Media.lastFrameJpeg(f) } else null
                }
            } else null
            Veo.generateClip(store, buildPrompt(sc, startImg != null), startImg, out)
            spent += cost; store.spentUsd = spent
            update(sc.id) { it.copy(busy = false, status = "Ready", clipPath = out.absolutePath) }
            persist()
            true
        } catch (e: CancellationException) {
            update(sc.id) { it.copy(busy = false, status = "Stopped") }
            throw e
        } catch (e: Exception) {
            update(sc.id) { it.copy(busy = false, status = "Failed", error = e.message ?: e.toString()) }
            message = "Scene ${idx + 1} par ruk gaya: ${e.message?.take(160)}"
            false
        }
    }

    private fun startKeepAlive() =
        ContextCompat.startForegroundService(app, Intent(app, KeepAliveService::class.java))
    private fun stopKeepAlive() { app.stopService(Intent(app, KeepAliveService::class.java)) }

    /** [limitCount] = how many new clips to make (null = all remaining). */
    fun generate(limitCount: Int?) {
        if (running) return
        job = viewModelScope.launch {
            running = true; startKeepAlive(); message = "Clips ban rahi hain..."
            try {
                var made = 0
                for (idx in scenes.indices) {
                    if (limitCount != null && made >= limitCount) break
                    val have = scenes[idx].clipPath?.let { File(it).exists() } == true
                    if (have) continue
                    if (!generateOne(idx)) break
                    made++
                }
                if (message.startsWith("Clips ban")) message = "Ho gaya: $made nayi clips."
            } finally {
                running = false; stopKeepAlive(); persist()
            }
        }
    }

    fun generateSingle(id: Int) {
        if (running) return
        job = viewModelScope.launch {
            running = true; startKeepAlive()
            try {
                val idx = scenes.indexOfFirst { it.id == id }
                if (idx >= 0) {
                    scenes[idx].clipPath?.let { File(it).delete() }
                    update(id) { it.copy(clipPath = null) }
                    generateOne(idx)
                }
            } finally { running = false; stopKeepAlive(); persist() }
        }
    }

    fun stop() { job?.cancel(); message = "Rok diya. Jo clip chal rahi thi uska kharch ho sakta hai." }

    // ---------- final video ----------
    fun joinClips() {
        viewModelScope.launch {
            message = "Clips jod raha hoon..."
            try {
                val files = scenes.mapNotNull { s -> s.clipPath?.let { File(it) } }.filter { it.exists() }
                require(files.isNotEmpty()) { "Abhi koi clip nahi bani." }
                val dir = app.getExternalFilesDir(null) ?: app.filesDir
                val out = File(dir, "story_${System.currentTimeMillis()}.mp4")
                withContext(Dispatchers.IO) {
                    Media.concat(files, out)
                    finalUri = Media.saveToGallery(app, out)
                }
                finalPath = out.absolutePath
                val missing = scenes.size - files.size
                message = "Video ban gayi: ${files.size} clips, Movies/StoryToons mein save." +
                    if (missing > 0) " ($missing scenes ki clip baaki hai.)" else ""
            } catch (e: Exception) {
                message = "Jodna fail hua: ${e.message}"
            }
        }
    }
}
