package com.storytoons.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import java.util.UUID

class AppVM(app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    var story by mutableStateOf(store.story)
    var style by mutableStateOf(store.style)
    val scenes = mutableStateListOf<Scene>()
    val characters = mutableStateListOf<Character>().apply { addAll(store.loadCharacters()) }

    var apiKey by mutableStateOf(store.apiKey)
    var baseUrl by mutableStateOf(store.baseUrl)
    var modelRef by mutableStateOf(store.modelWithRefs)
    var modelTxt by mutableStateOf(store.modelTextOnly)

    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(app) { st ->
            if (st == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
        }
    }

    fun saveSettings() {
        store.apiKey = apiKey.trim()
        store.baseUrl = baseUrl.trim()
        store.modelWithRefs = modelRef.trim()
        store.modelTextOnly = modelTxt.trim()
    }

    fun setStyleChoice(name: String) { style = name; store.style = name }
    fun setStoryText(t: String) { story = t; store.story = t }

    // ---- scenes ----
    fun splitScenes() {
        val chunks = mutableListOf<String>()
        story.split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }.forEach { para ->
            if (para.length <= 260) chunks += para
            else {
                var cur = ""
                para.split(Regex("(?<=[.!?।])\\s+")).forEach { sent ->
                    if (cur.isNotEmpty() && cur.length + sent.length > 260) { chunks += cur; cur = sent }
                    else cur = if (cur.isEmpty()) sent else "$cur $sent"
                }
                if (cur.isNotEmpty()) chunks += cur
            }
        }
        scenes.clear()
        chunks.forEachIndexed { i, t ->
            scenes += Scene(i, t, Cameras.all[i % Cameras.all.size])
        }
    }

    private fun update(id: Int, f: (Scene) -> Scene) {
        val i = scenes.indexOfFirst { it.id == id }
        if (i >= 0) scenes[i] = f(scenes[i])
    }

    fun nextCamera(id: Int) = update(id) {
        val n = (Cameras.all.indexOf(it.camera) + 1) % Cameras.all.size
        it.copy(camera = Cameras.all[n])
    }

    fun buildPrompt(sc: Scene): String {
        val cast = characters.joinToString(" ") { "${it.name}: ${it.desc}." }
        return buildString {
            append(Styles.all[style]).append(". Vertical 9:16 video. ")
            if (cast.isNotBlank()) append("Characters: $cast ")
            append("Keep every character identical to the reference sheets (front, back, left and right views). ")
            append("When a character walks away or turns, show the correct back or side view. ")
            append("Camera: ${sc.camera}. ")
            append("Scene: ${sc.text} ")
            append("Natural lip-sync for any dialogue, fitting ambient sound.")
        }
    }

    fun generate(id: Int) {
        val sc = scenes.firstOrNull { it.id == id } ?: return
        if (sc.busy) return
        viewModelScope.launch {
            update(id) { it.copy(busy = true, status = "Generating... (1-5 min)", error = null) }
            try {
                val refs = characters.mapNotNull { c -> c.sheetPath?.let { Seedance.imageToDataUri(it) } }
                val url = Seedance.generate(store, buildPrompt(sc), refs)
                update(id) { it.copy(busy = false, status = "Video ready", videoUrl = url) }
            } catch (e: Exception) {
                update(id) { it.copy(busy = false, status = "Failed", error = e.message ?: e.toString()) }
            }
        }
    }

    fun generateAll() {
        viewModelScope.launch {
            for (sc in scenes.toList()) {
                if (sc.videoUrl != null) continue
                update(sc.id) { it.copy(busy = true, status = "Generating... (1-5 min)", error = null) }
                try {
                    val refs = characters.mapNotNull { c -> c.sheetPath?.let { Seedance.imageToDataUri(it) } }
                    val url = Seedance.generate(store, buildPrompt(sc), refs)
                    update(sc.id) { it.copy(busy = false, status = "Video ready", videoUrl = url) }
                } catch (e: Exception) {
                    update(sc.id) { it.copy(busy = false, status = "Failed", error = e.message ?: e.toString()) }
                    break
                }
            }
        }
    }

    fun narrate(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "scene") }

    // ---- characters ----
    fun addCharacter(name: String, desc: String) {
        characters += Character(UUID.randomUUID().toString(), name.trim(), desc.trim())
        store.saveCharacters(characters)
    }

    fun removeCharacter(c: Character) {
        characters.remove(c)
        c.sheetPath?.let { File(it).delete() }
        store.saveCharacters(characters)
    }

    fun setSheet(c: Character, uri: Uri) {
        val ctx = getApplication<Application>()
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
        val f = File(ctx.filesDir, "sheet_${c.id}.jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        val i = characters.indexOfFirst { it.id == c.id }
        if (i >= 0) characters[i] = c.copy(sheetPath = f.absolutePath)
        store.saveCharacters(characters)
    }

    override fun onCleared() { tts?.shutdown() }
}
