package com.storytoons.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer

object Media {
    fun lastFrameJpeg(f: File): ByteArray? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.absolutePath)
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: return null
            val bmp = r.getFrameAtTime(maxOf(0L, durMs - 120) * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
                ?: r.getFrameAtTime(maxOf(0L, durMs - 400) * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
                ?: return null
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, bos)
            bos.toByteArray()
        } catch (e: Exception) { null } finally { r.release() }
    }

    /** Joins MP4 clips that share the same codec settings (all Veo clips do) without re-encoding. */
    fun concat(files: List<File>, out: File) {
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var vIdx = -1
        var aIdx = -1
        var offset = 0L
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        try {
            files.forEachIndexed { fi, f ->
                val ex = MediaExtractor()
                ex.setDataSource(f.absolutePath)
                var vT = -1
                var aT = -1
                for (t in 0 until ex.trackCount) {
                    val mime = ex.getTrackFormat(t).getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("video") && vT < 0) vT = t
                    else if (mime.startsWith("audio") && aT < 0) aT = t
                }
                if (fi == 0) {
                    if (vT >= 0) vIdx = muxer.addTrack(ex.getTrackFormat(vT))
                    if (aT >= 0) aIdx = muxer.addTrack(ex.getTrackFormat(aT))
                    muxer.start()
                }
                var maxEnd = 0L
                for ((track, idx) in listOf(vT to vIdx, aT to aIdx)) {
                    if (track < 0 || idx < 0) continue
                    ex.selectTrack(track)
                    ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                    while (true) {
                        buf.clear()
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) break
                        val t = ex.sampleTime
                        val key = (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                        info.set(0, size, t + offset, if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                        muxer.writeSampleData(idx, buf, info)
                        if (t > maxEnd) maxEnd = t
                        ex.advance()
                    }
                    ex.unselectTrack(track)
                }
                offset += maxEnd + 33_000
                ex.release()
            }
        } finally {
            try { muxer.stop() } catch (e: Exception) { }
            muxer.release()
        }
    }

    fun saveToGallery(ctx: Context, f: File): Uri? {
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/StoryToons")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        return uri
    }
}
