package com.storytoons.app

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class ApiError(message: String, val code: Int) : Exception(message)

class PScene(val action: String, val camera: String, val newLocation: Boolean)
class Plan(val world: String, val characters: List<Pair<String, String>>, val scenes: List<PScene>)

object Veo {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    private fun errText(t: String): String = try {
        JSONObject(t).getJSONObject("error").getString("message")
    } catch (e: Exception) { t.take(300) }

    private fun call(req: Request): String = http.newCall(req).execute().use { r ->
        val t = r.body?.string().orEmpty()
        if (!r.isSuccessful) throw ApiError("Google error ${r.code}: ${errText(t)}", r.code)
        t
    }

    private fun post(store: Store, url: String, body: JSONObject) = Request.Builder()
        .url(url).header("x-goog-api-key", store.apiKey)
        .post(body.toString().toRequestBody("application/json".toMediaType())).build()

    private fun findKey(any: Any?, key: String): String? {
        when (any) {
            is JSONObject -> {
                if (any.has(key) && any.opt(key) is String) return any.getString(key)
                for (k in any.keys()) findKey(any.opt(k), key)?.let { return it }
            }
            is JSONArray -> for (i in 0 until any.length()) findKey(any.opt(i), key)?.let { return it }
        }
        return null
    }

    private val longHttp = http.newBuilder().readTimeout(15, TimeUnit.MINUTES).build()

    /** Makes one clip with Gemini Omni (Interactions API) and saves it to [out]. */
    suspend fun generateClip(
        store: Store, prompt: String, startImageJpeg: ByteArray?, out: File
    ) = withContext(Dispatchers.IO) {
        require(store.apiKey.isNotBlank()) { "Settings mein Gemini API key daalo." }
        val base = store.baseUrl.trimEnd('/')

        val input: Any = if (startImageJpeg == null) prompt else JSONArray()
            .put(JSONObject().put("type", "image")
                .put("data", Base64.encodeToString(startImageJpeg, Base64.NO_WRAP))
                .put("mime_type", "image/jpeg"))
            .put(JSONObject().put("type", "text").put("text", "<FIRST_FRAME> $prompt"))

        val body = JSONObject()
            .put("model", store.videoModel)
            .put("input", input)
            .put("response_format", JSONObject()
                .put("type", "video")
                .put("aspect_ratio", "9:16")
                .put("resolution", store.resolution)
                .put("delivery", "uri"))

        var resp: String? = null
        var attempt = 0
        while (resp == null) {
            try {
                resp = longHttp.newCall(post(store, "$base/interactions", body)).execute().use { r ->
                    val t = r.body?.string().orEmpty()
                    if (!r.isSuccessful) throw ApiError("Google error ${r.code}: ${errText(t)}", r.code)
                    t
                }
            } catch (e: ApiError) {
                if ((e.code == 429 || e.code == 503) && attempt < 4) { attempt++; delay(60_000L * attempt) }
                else throw e
            }
        }

        val j = JSONObject(resp)
        val status = j.optString("status")
        if (status == "failed" || status == "cancelled") throw Exception("Generation fail: ${resp.take(250)}")
        var uri: String? = null
        var data: String? = null
        val steps = j.optJSONArray("steps")
        if (steps != null) {
            for (i in 0 until steps.length()) {
                val content = steps.getJSONObject(i).optJSONArray("content") ?: continue
                for (k in 0 until content.length()) {
                    val c = content.getJSONObject(k)
                    if (c.optString("type") == "video") {
                        if (c.optString("uri").isNotBlank()) uri = c.getString("uri")
                        if (c.optString("data").isNotBlank()) data = c.getString("data")
                    }
                }
            }
        }
        out.parentFile?.mkdirs()
        if (data != null) {
            out.writeBytes(Base64.decode(data, Base64.DEFAULT))
            return@withContext
        }
        if (uri == null) throw Exception("Video nahi mili (shayad safety filter ne roka): ${resp.take(250)}")

        // wait until Google's file is ACTIVE, then download
        val id = Regex("files/([A-Za-z0-9_-]+)").find(uri)?.groupValues?.get(1)
        if (id != null) {
            repeat(60) {
                val t = call(Request.Builder().url("$base/files/$id").header("x-goog-api-key", store.apiKey).build())
                val st = JSONObject(t).optString("state")
                if (st == "ACTIVE") return@repeat
                if (st == "FAILED") throw Exception("Video processing fail hui.")
                delay(5000)
            }
        }
        download(store, uri, out)
    }

    private fun download(store: Store, uri: String, out: File) {
        val req = Request.Builder().url(uri).header("x-goog-api-key", store.apiKey).build()
        longHttp.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw ApiError("Download fail (${r.code})", r.code)
            r.body!!.byteStream().use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    /** Uses Gemini text model to build the story world, characters and shot list. */
    suspend fun planStory(store: Store, story: String, sceneCount: Int, style: String): Plan =
        withContext(Dispatchers.IO) {
            require(store.apiKey.isNotBlank()) { "Settings mein Gemini API key daalo." }
            val base = store.baseUrl.trimEnd('/')
            val instruction = """
You are a film director adapting a story into exactly $sceneCount consecutive 8-second vertical video shots.
Return ONLY JSON in this shape:
{"world":"visual style, setting, lighting and colour notes shared by all shots",
 "characters":[{"name":"","look":"fixed detailed appearance: age, face, hair, clothes, colours"}],
 "scenes":[{"action":"what visibly happens in 8 seconds, max 45 words; put spoken dialogue in double quotes with the speaker's name","camera":"one camera movement","new_location":false}]}
Rules: keep every character visually identical in all shots. Keep dialogue in the story's original language. Set new_location true only when the place changes. Visual style: $style.
Story:
$story
""".trimIndent()
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", instruction)))))
                .put("generationConfig", JSONObject()
                    .put("responseMimeType", "application/json"))
            val t = call(post(store, "$base/models/${store.textModel}:generateContent", body))
            val raw = JSONObject(t).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val clean = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val j = JSONObject(clean)
            val chars = j.optJSONArray("characters")?.let { a ->
                (0 until a.length()).map {
                    val o = a.getJSONObject(it); o.optString("name") to o.optString("look")
                }
            } ?: emptyList()
            val sc = j.getJSONArray("scenes")
            val scenes = (0 until sc.length()).map {
                val o = sc.getJSONObject(it)
                PScene(o.optString("action"), o.optString("camera", Cameras.all[it % Cameras.all.size]),
                    o.optBoolean("new_location", false))
            }
            if (scenes.isEmpty()) throw Exception("Scenes nahi mile")
            Plan(j.optString("world"), chars, scenes)
        }
}
