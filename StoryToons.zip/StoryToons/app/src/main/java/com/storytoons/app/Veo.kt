package com.storytoons.app

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class ApiError(message: String, val code: Int) : Exception(message)

class PChar(val name: String, val look: String, val voice: String)
class PPlace(val name: String, val look: String)
class PScene(val action: String, val camera: String, val location: String, val chars: List<String>)
class Plan(val world: String, val chars: List<PChar>, val places: List<PPlace>, val scenes: List<PScene>)

/** Talks to the Gemini API: story planning, image generation and Gemini Omni video. */
object Veo {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(2, TimeUnit.MINUTES)
        .readTimeout(15, TimeUnit.MINUTES)
        .build()

    private fun errText(t: String): String = try {
        JSONObject(t).getJSONObject("error").getString("message")
    } catch (e: Exception) { t.take(300) }

    private fun send(store: Store, url: String, body: JSONObject): String {
        val req = Request.Builder().url(url).header("x-goog-api-key", store.apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        return http.newCall(req).execute().use { r ->
            val t = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiError("Google error ${r.code}: ${errText(t)}", r.code)
            t
        }
    }

    private suspend fun sendRetry(store: Store, url: String, body: JSONObject): String {
        var attempt = 0
        while (true) {
            try {
                return send(store, url, body)
            } catch (e: ApiError) {
                if ((e.code == 429 || e.code == 503) && attempt < 4) { attempt++; delay(60_000L * attempt) }
                else throw e
            }
        }
    }

    private fun getText(store: Store, url: String): String {
        val req = Request.Builder().url(url).header("x-goog-api-key", store.apiKey).build()
        return http.newCall(req).execute().use { r ->
            val t = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiError("Google error ${r.code}: ${errText(t)}", r.code)
            t
        }
    }

    private fun needKey(store: Store) {
        require(store.apiKey.isNotBlank()) { "Settings mein Gemini API key daalo." }
    }

    // ------------------------------------------------------------------ video
    /** Makes one clip with Gemini Omni. [refs] are JPEG reference images (tagged in the prompt). */
    suspend fun generateClip(
        store: Store, prompt: String, refs: List<ByteArray>, out: File
    ) = withContext(Dispatchers.IO) {
        needKey(store)
        val base = store.baseUrl.trimEnd('/')

        val input: Any = if (refs.isEmpty()) prompt else JSONArray().apply {
            refs.forEach {
                put(JSONObject().put("type", "image")
                    .put("data", Base64.encodeToString(it, Base64.NO_WRAP))
                    .put("mime_type", "image/jpeg"))
            }
            put(JSONObject().put("type", "text").put("text", prompt))
        }

        val body = JSONObject()
            .put("model", store.videoModel)
            .put("input", input)
            .put("response_format", JSONObject()
                .put("type", "video")
                .put("aspect_ratio", "9:16")
                .put("resolution", store.resolution)
                .put("delivery", "uri"))

        val resp = sendRetry(store, "$base/interactions", body)
        val j = JSONObject(resp)
        val status = j.optString("status")
        if (status == "failed" || status == "cancelled") throw Exception("Generation fail: ${resp.take(250)}")

        var uri: String? = null
        var data: String? = null
        val steps = j.optJSONArray("steps")
        if (steps != null) {
            for (i in 0 until steps.length()) {
                val content = steps.getJSONObject(i).optJSONArray("content") ?: continue
                for (k in 0 until content.length()) {
                    val c = content.getJSONObject(k)
                    if (c.optString("type") == "video") {
                        if (c.optString("uri").isNotBlank()) uri = c.getString("uri")
                        if (c.optString("data").isNotBlank()) data = c.getString("data")
                    }
                }
            }
        }
        out.parentFile?.mkdirs()
        if (data != null) {
            out.writeBytes(Base64.decode(data, Base64.DEFAULT))
            return@withContext
        }
        if (uri == null) throw Exception("Video nahi mili (shayad safety filter ne roka): ${resp.take(250)}")

        val id = Regex("files/([A-Za-z0-9_-]+)").find(uri)?.groupValues?.get(1)
        if (id != null) {
            var active = false
            var tries = 0
            while (!active && tries < 60) {
                tries++
                val st = JSONObject(getText(store, "$base/files/$id")).optString("state")
                when (st) {
                    "FAILED" -> throw Exception("Video processing fail hui.")
                    "PROCESSING" -> delay(5000)
                    else -> active = true
                }
            }
        }
        val req = Request.Builder().url(uri).header("x-goog-api-key", store.apiKey).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw ApiError("Download fail (${r.code})", r.code)
            r.body!!.byteStream().use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    // ------------------------------------------------------------------ images
    suspend fun generateImage(store: Store, prompt: String): ByteArray = withContext(Dispatchers.IO) {
        needKey(store)
        val base = store.baseUrl.trimEnd('/')
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val t = sendRetry(store, "$base/models/${store.imageModel}:generateContent", body)
        val data = findInline(JSONObject(t)) ?: throw Exception("Image nahi bani: ${t.take(200)}")
        Base64.decode(data, Base64.DEFAULT)
    }

    private fun findInline(any: Any?): String? {
        when (any) {
            is JSONObject -> {
                val inl = any.optJSONObject("inlineData") ?: any.optJSONObject("inline_data")
                if (inl != null && inl.optString("data").isNotBlank()) return inl.getString("data")
                for (k in any.keys()) findInline(any.opt(k))?.let { return it }
            }
            is JSONArray -> for (i in 0 until any.length()) findInline(any.opt(i))?.let { return it }
        }
        return null
    }

    // ------------------------------------------------------------------ planning
    fun planInstruction(story: String, sceneCount: Int, style: String): String = """
You are a film director adapting a story into exactly $sceneCount consecutive 8-second vertical video shots.
Return ONLY JSON in this shape (no explanation before or after):
{"world":"shared visual style, lighting and colour notes, max 60 words",
 "characters":[{"name":"","look":"fixed detailed appearance: age, face, hair, clothes, colours, max 40 words","voice":"voice: age, pitch, tone, accent"}],
 "locations":[{"name":"","look":"detailed look of the place, max 40 words"}],
 "scenes":[{"action":"what visibly happens in 8 seconds, max 45 words; spoken dialogue in double quotes with the speaker's name","camera":"one camera movement","location":"exactly one of the location names","characters":["names of characters present in this shot"]}]}
Rules: every character must look identical in all shots. Keep dialogue in the story's original language. Use as few locations as the story allows. Visual style: $style.
Story:
$story
""".trimIndent()

    fun parsePlan(raw: String): Plan {
        val a = raw.indexOf('{')
        val b = raw.lastIndexOf('}')
        if (a < 0 || b <= a) throw Exception("JSON nahi mila")
        val j = JSONObject(raw.substring(a, b + 1))
        val chars = j.optJSONArray("characters")?.let { arr ->
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                PChar(o.optString("name"), o.optString("look"), o.optString("voice"))
            }
        } ?: emptyList()
        val places = j.optJSONArray("locations")?.let { arr ->
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it); PPlace(o.optString("name"), o.optString("look"))
            }
        } ?: emptyList()
        val sc = j.getJSONArray("scenes")
        val scenes = (0 until sc.length()).map {
            val o = sc.getJSONObject(it)
            val cj = o.optJSONArray("characters")
            PScene(
                o.optString("action"),
                o.optString("camera").ifBlank { Cameras.all[it % Cameras.all.size] },
                o.optString("location"),
                if (cj == null) emptyList() else (0 until cj.length()).map { i -> cj.getString(i) }
            )
        }
        if (scenes.isEmpty()) throw Exception("Scenes nahi mile")
        return Plan(j.optString("world"), chars, places, scenes)
    }

    suspend fun planStory(store: Store, story: String, sceneCount: Int, style: String): Plan =
        withContext(Dispatchers.IO) {
            needKey(store)
            val base = store.baseUrl.trimEnd('/')
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", planInstruction(story, sceneCount, style))))))
                .put("generationConfig", JSONObject()
                    .put("responseMimeType", "application/json")
                    .put("thinkingConfig", JSONObject().put("thinkingLevel", "low")))
            val t = sendRetry(store, "$base/models/${store.textModel}:generateContent", body)
            val raw = JSONObject(t).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            parsePlan(raw)
        }
}
