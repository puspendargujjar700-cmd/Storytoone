# StoryToons 0.2 (Gemini Omni Flash)

Paste a story, set minutes, build the story world, generate 8-second clips with Gemini Omni Flash,
join them into one MP4.

Settings -> paste your Gemini API key (aistudio.google.com/apikey), set a spend limit.
Test with "Test 3 clips" first.

Build: upload StoryToons.zip + .github/workflows/build.yml to GitHub, run Actions, download the APK artifact.
