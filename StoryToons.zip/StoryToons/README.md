# StoryToons

Paste a story, add characters with 4-view sheets, pick a style, generate Seedance 2.5 clips.

## Build the APK
1. Upload all these files to a GitHub repo (keep the folder structure).
2. Open the Actions tab, run "Build APK" (or just push).
3. When it turns green, download the APK from Artifacts.

## Use
Settings -> paste your API key (Atlas Cloud by default). Story -> paste text -> Split into scenes -> Generate.
