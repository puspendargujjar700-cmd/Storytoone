# StoryToons 0.5

Free mode (Google AI Pro/Ultra subscription, no API key):
1. Paste story -> "Send story to Gemini app" -> copy Gemini's JSON reply -> "Paste Gemini's plan".
2. World tab: make character sheets / place images in the Gemini app, then "Use my image".
3. Each scene: "Prompt to Gemini" -> make the video in the Gemini app -> "Import clip".
4. "Join clips into one MP4".

Optional API mode (paid key from aistudio.google.com/apikey) still works.
